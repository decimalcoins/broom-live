import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  try {
    // In production, this would call your backend to generate a LiveKit token
    // For now, return a mock token
    const token = `viewer_token_${id}_${Date.now()}`

    return NextResponse.json({ token })
  } catch (error) {
    console.error("[v0] Failed to generate viewer token:", error)
    return NextResponse.json({ error: "Failed to generate token" }, { status: 500 })
  }
}
