import { Room } from "livekit-client"

export interface LiveKitConfig {
  url: string
  token: string
}

export class LiveKitService {
  private room: Room | null = null

  async connect(config: LiveKitConfig): Promise<Room> {
    this.room = new Room({
      adaptiveStream: true,
      dynacast: true,
    })

    await this.room.connect(config.url, config.token)
    return this.room
  }

  disconnect() {
    this.room?.disconnect()
    this.room = null
  }

  getRoom(): Room | null {
    return this.room
  }

  async enableCamera(): Promise<void> {
    if (!this.room) throw new Error("Room not connected")
    await this.room.localParticipant.setCameraEnabled(true)
  }

  async disableCamera(): Promise<void> {
    if (!this.room) throw new Error("Room not connected")
    await this.room.localParticipant.setCameraEnabled(false)
  }

  async enableMicrophone(): Promise<void> {
    if (!this.room) throw new Error("Room not connected")
    await this.room.localParticipant.setMicrophoneEnabled(true)
  }

  async disableMicrophone(): Promise<void> {
    if (!this.room) throw new Error("Room not connected")
    await this.room.localParticipant.setMicrophoneEnabled(false)
  }
}
