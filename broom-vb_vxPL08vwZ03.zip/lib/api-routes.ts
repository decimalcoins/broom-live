import { BACKEND_CONFIG } from "./system-config"

// API route constants
export const API_ROUTES = {
  // User routes
  GET_USER: (userId: string) => `${BACKEND_CONFIG.BASE_URL}/v1/users/${userId}`,
  UPDATE_USER: (userId: string) => `${BACKEND_CONFIG.BASE_URL}/v1/users/${userId}`,
  GET_USER_COINS: (userId: string) => `${BACKEND_CONFIG.BASE_URL}/v1/users/${userId}/coins`,

  // Stream routes
  GET_STREAMS: `${BACKEND_CONFIG.BASE_URL}/v1/streams`,
  GET_STREAM: (streamId: string) => `${BACKEND_CONFIG.BASE_URL}/v1/streams/${streamId}`,
  CREATE_STREAM: `${BACKEND_CONFIG.BASE_URL}/v1/streams`,
  UPDATE_STREAM: (streamId: string) => `${BACKEND_CONFIG.BASE_URL}/v1/streams/${streamId}`,
  START_STREAM: (streamId: string) => `${BACKEND_CONFIG.BASE_URL}/v1/streams/${streamId}/start`,
  END_STREAM: (streamId: string) => `${BACKEND_CONFIG.BASE_URL}/v1/streams/${streamId}/end`,

  // Gift routes
  GET_GIFTS: `${BACKEND_CONFIG.BASE_URL}/v1/gifts`,
  SEND_GIFT: `${BACKEND_CONFIG.BASE_URL}/v1/gifts/send`,

  // Transaction routes
  GET_TRANSACTIONS: (userId: string) => `${BACKEND_CONFIG.BASE_URL}/v1/users/${userId}/transactions`,
  PURCHASE_COINS: `${BACKEND_CONFIG.BASE_URL}/v1/transactions/purchase-coins`,

  // Withdrawal routes
  GET_WITHDRAWALS: (hostId: string) => `${BACKEND_CONFIG.BASE_URL}/v1/withdrawals/host/${hostId}`,
  REQUEST_WITHDRAWAL: `${BACKEND_CONFIG.BASE_URL}/v1/withdrawals/request`,
  GET_ALL_WITHDRAWALS: `${BACKEND_CONFIG.BASE_URL}/v1/admin/withdrawals`,
  PROCESS_WITHDRAWAL: (withdrawalId: string) =>
    `${BACKEND_CONFIG.BASE_URL}/v1/admin/withdrawals/${withdrawalId}/process`,

  // Config routes
  GET_CONFIG: `${BACKEND_CONFIG.BASE_URL}/v1/config`,
  UPDATE_CONFIG: `${BACKEND_CONFIG.BASE_URL}/v1/admin/config`,

  // Chat routes (WebSocket)
  CHAT_WS: (streamId: string) => `wss://backend.appstudio-u7cm9zhmha0ruwv8.piappengine.com/v1/streams/${streamId}/chat`,
} as const
