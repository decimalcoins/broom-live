"use client"

import { useEffect, useState } from "react"
import { useLiveKit } from "@/hooks/use-livekit"
import { VideoPlayer } from "./video-player"
import { Button } from "./ui/button"
import { Video, VideoOff, Mic, MicOff, StopCircle } from "lucide-react"
import { Card } from "./ui/card"
import { api } from "@/lib/api"
import { API_ROUTES } from "@/lib/api-routes"
import { Track } from "livekit-client"

interface HostStreamViewProps {
  streamId: string
  onEndStream: () => void
}

export function HostStreamView({ streamId, onEndStream }: HostStreamViewProps) {
  const [token, setToken] = useState<string | null>(null)
  const { room, isConnected, cameraEnabled, micEnabled, connect, disconnect, toggleCamera, toggleMic } = useLiveKit(
    streamId,
    token,
  )

  useEffect(() => {
    // Fetch LiveKit token from backend
    const fetchToken = async () => {
      try {
        const response = await api.post<{ token: string }>(API_ROUTES.START_STREAM(streamId))
        setToken(response.data.token)
      } catch (err) {
        console.error("[v0] Failed to fetch stream token:", err)
      }
    }

    fetchToken()
  }, [streamId])

  useEffect(() => {
    if (token) {
      connect()
    }

    return () => {
      disconnect()
    }
  }, [token, connect, disconnect])

  const handleEndStream = async () => {
    try {
      await api.post(API_ROUTES.END_STREAM(streamId))
      disconnect()
      onEndStream()
    } catch (err) {
      console.error("[v0] Failed to end stream:", err)
    }
  }

  const localVideoTrack = room?.localParticipant.getTrackPublication(Track.Source.Camera)

  return (
    <div className="flex flex-col h-screen bg-background">
      <div className="relative flex-1 bg-black">
        {localVideoTrack ? (
          <VideoPlayer track={localVideoTrack} isLocal className="w-full h-full" />
        ) : (
          <div className="flex items-center justify-center w-full h-full text-white">
            <p>Camera is off</p>
          </div>
        )}

        <div className="absolute top-4 right-4">
          <Card className="px-3 py-2 bg-black/60 text-white border-white/20">
            <p className="text-sm">{isConnected ? "LIVE" : "Connecting..."}</p>
          </Card>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
          <div className="flex items-center justify-center gap-4">
            <Button
              size="lg"
              variant={cameraEnabled ? "default" : "destructive"}
              onClick={toggleCamera}
              className="rounded-full w-14 h-14"
            >
              {cameraEnabled ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
            </Button>

            <Button
              size="lg"
              variant={micEnabled ? "default" : "destructive"}
              onClick={toggleMic}
              className="rounded-full w-14 h-14"
            >
              {micEnabled ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
            </Button>

            <Button size="lg" variant="destructive" onClick={handleEndStream} className="rounded-full w-14 h-14">
              <StopCircle className="w-6 h-6" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
